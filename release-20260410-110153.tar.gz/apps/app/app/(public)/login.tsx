import { useState } from "react";
import { View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Card, Eyebrow, Field, PrimaryButton, Screen, Title, Body } from "../../src/components/ui";
import { useAuth } from "../../src/state/auth";

export default function LoginScreen() {
  const { login } = useAuth();
  const [email, setEmail] = useState("admin@demo.com");
  const [password, setPassword] = useState("Admin123!");

  return (
    <LinearGradient colors={["#02111b", "#103b39"]} style={{ flex: 1 }}>
      <Screen>
        <Card>
          <Eyebrow>MVP listo para validar</Eyebrow>
          <Title>Gestion odontologica multi-tenant con foco comercial real.</Title>
          <Body>La nueva app usa React Native y tambien corre sobre web con la misma base visual.</Body>
        </Card>

        <Card>
          <Title>Ingresar</Title>
          <View style={{ gap: 12 }}>
            <Field value={email} onChangeText={setEmail} autoCapitalize="none" placeholder="Email" />
            <Field value={password} onChangeText={setPassword} secureTextEntry placeholder="Password" />
            <PrimaryButton
              label="Entrar"
              onPress={async () => {
                await login(email, password);
                router.replace("/(app)/dashboard");
              }}
            />
          </View>
        </Card>
      </Screen>
    </LinearGradient>
  );
}
